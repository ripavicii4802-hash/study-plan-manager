# AI 기반 공부 계획 평가 시스템

## 1. 프로젝트 소개

본 프로젝트는 학생들이 공부 계획을 효율적으로 관리할 수 있도록 돕는 프로그램입니다.

사용자는 공부할 항목, 과목, 공부 시간, 우선순위, 마감일, 완료 여부를 입력할 수 있습니다.  
입력된 데이터를 바탕으로 전체 공부 시간과 완료율을 확인할 수 있으며, 과목별 공부 시간을 그래프로 확인할 수 있습니다.  
또한 OpenAI API를 활용하여 AI가 공부 계획의 현실성, 우선순위, 마감 위험, 개선 방향을 직접 분석합니다.

## 2. 주요 기능

- 할 일 추가
- 과목 입력
- 공부 시간 입력
- 우선순위 설정
- 마감일 입력
- 완료 여부 표시
- 공부 진행률 분석
- 과목별 공부 시간 그래프 시각화
- 데이터 저장 및 불러오기
- AI 공부 계획 분석

## 3. 사용 기술

- Python
- Tkinter
- JSON
- Matplotlib
- OpenAI API
- PyInstaller

## 4. 실행 방법

### 4-1. Python으로 실행하는 방법

```bash
cd src
pip install -r requirements.txt
python main.py
```

### 4-2. 실행파일로 실행하는 방법

`exe` 폴더 안에 있는 `build_exe.bat`을 실행하면 `study_manager.exe`를 만들 수 있습니다.

```bash
exe/build_exe.bat
```

생성된 실행파일은 `dist/study_manager.exe` 위치에 만들어집니다.

## 5. API 키 설정 방법

AI 분석 기능을 사용하려면 `src` 폴더 안에 `.env` 파일을 만들어야 합니다.

`.env` 파일 내용 예시:

```text
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-5.5
```

주의: `.env` 파일에는 실제 API 키가 들어가므로 GitHub에 올리지 않습니다.  
GitHub에는 `.env.example` 파일만 업로드합니다.

## 6. 팀원 역할

| 이름 | 역할 |
|---|---|
| 김광표 | 시스템 코딩 및 발표 |
| 김대희 | 기획 및 PPT 제작 |

## 7. 향후 보완할 점

- 시험 일정 기반 학습 계획 자동 생성
- 알림 기능 추가
- 바탕화면 위젯 기능 추가
- 모바일 앱 연동
- 사용자별 계정 기능 추가
